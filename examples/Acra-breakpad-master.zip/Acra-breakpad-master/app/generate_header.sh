javah -classpath ./target/classes -o ./jni/native_lib.h name.antonsmirnov.android.acra_breakpad.app.NativeLib
