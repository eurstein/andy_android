javah -classpath ./target/classes -o ./jni/native_exception_handler.h name.antonsmirnov.android.acra_breakpad.NativeExceptionHandler
