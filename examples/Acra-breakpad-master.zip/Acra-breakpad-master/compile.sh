mvn clean install -Dandroid.sdk.path=/softdev/android-sdk_r21/
